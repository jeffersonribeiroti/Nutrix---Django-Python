from django.db import models
from django.contrib.auth.models import User #<-- 2
# 2 - Importa o modelo User do sistema de autenticação do Django (django.contrib.auth).
# 2 - User é a tabela de usuários padrão (contém username, password, email, is_staff, etc.).
# 2- Usamos esse User para relacionar nossos perfis (Cliente / Nutricionista) ao usuário que efetua login.


class Cliente (models.Model): 
    "Criando a classe cliente que se tornará uma tabela no banco de dados."
    user = models.OneToOneField(User,on_delete=models.CASCADE,related_name = 'cliente')
    # OneToOneField - Nada mais indica relacionamento de N para N no banco de Dados(primary Key)
    # Quer dizer que a instância de um Cliente está ligada a um User, e um User está ligado a no máximo um Cliente..
    telefone = models.CharField(max_length=20, blank=True, null = True)
    # campo telefone com máximo de (tamanho = 20), além de permitir ser nulo tanto no banco de dados, quanto no Django.
    data_nascimento = models.DateField(null = True , blank = True)
    #Campo data_nascimento recebe apenas data ,além de permitir ser nulo no banco de dados, quanto no Django.

    def __str__(self):
        return f'Cliente:{self.user.username}'
    """ Define o método especial __str__, usado para representação legível do objeto (útil no admin, shell e logs).
        Retorna uma string formatada com o username do User associado.
        f"Cliente: {self.user.username}" é um f-string do Python — concisa e legível."""
    
class Nutricionista : 
    user = models.OneToOneField(User,on_delete=models.CASCATE,related_name='nutricionista')
    telefone = models.CharField(blank = True , null = True)
    data_nascimento = models.DateField(null = True , blank = True)
    #crn = 

class Consulta : 
