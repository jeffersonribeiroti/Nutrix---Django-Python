from django.apps import AppConfig


class NutrixConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "nutrix"
