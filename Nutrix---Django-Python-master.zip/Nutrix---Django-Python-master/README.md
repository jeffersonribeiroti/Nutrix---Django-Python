# Nutrix---Django_Python
Projetinho voltado para Nutricionistas
# Idéia do Projeto : 
Sistema para Nutricionistas e Clientes , onde é possível solicitar consultas ou plano alimentar, vizualizar histórico de agendamentos, enviar plano alimentar ,etc...
## Link para o Curso de Django 
https://www.youtube.com/playlist?list=PLLVddSbilcumgeyk0z6ko5U_FYPfbRO2C
# Colocar repositório no ar ()
https://vercel.com/
